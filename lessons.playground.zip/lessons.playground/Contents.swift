import UIKit
//1 lesson:

var str = "Hello, playground"

var first = "one"

let constanta = 1
    

var iMac = "apple"

let apple = "iMac"


//2 lesson:


var a1: Int = 1


var a2: Float = 2.5


var a = a1 + Int(a2)

//3 lesson:


var iMac1 = "apple"

var iMac2: String = "apple"

var char: Character = "y"

iMac1 = String(char)

print(apple)


for c in "Hello Roma".Strings {
    
    print (c)
}

//4 lesson:
let constArray = [1,2,3,4,5]

constArray.count

print(constArray)


//5 lesson:

let dic1 = [0: "January", 1: "February", 2: "March", 3: "April", 4: "May", 5: "June", 6: "Jule", 7: "August", 8: "September", 9: "October", 10: "November", 11: "December"]

let dic2 = [0: "Январь", 1: "Февраль", 2: "Март", 3: "Апрель", 4: "Май", 5: "Июнь", 6: "Июль", 7: "Август", 8: "Сентябрь", 9: "Октябрь", 10: "Ноябрь", 11: "Декабрь"]
let dic3 = [0: "iOS", 1: "Android"]

let dict4 = [0: 1, 1: 1]

let dict5 = [0: true, 1: false]

let dict6 = [0: 0.05 , 1: 0.1]

let dict7 = [0: 101, 1: 102]

let dict8 = [0: "apple", 1: "windows"]

let dict9 = [0: "xCode", 1: "notepad++"]

let dict10 = [0: 909, 1: 908]

var dict11 = [0: 1]

//6 lesson:







